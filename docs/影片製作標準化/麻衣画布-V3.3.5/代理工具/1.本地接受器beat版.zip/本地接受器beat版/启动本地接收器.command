#!/bin/bash
# QiaoDoumayi 本地接收器 - Mac 一键启动
# 双击此文件即可在终端中启动服务

# 切换到脚本所在目录（双击运行时当前目录是用户主目录）
cd "$(dirname "$0")"

# UTF-8 输出
export LANG=zh_CN.UTF-8
export LC_ALL=zh_CN.UTF-8

clear
echo ""
echo "========================================"
echo "  QiaoDoumayi 本地接收器"
echo "========================================"
echo ""

# 优先使用 python3，其次 python
if command -v python3 &>/dev/null; then
    PYTHON=python3
elif command -v python &>/dev/null; then
    PYTHON=python
else
    echo "[错误] 未找到 Python！"
    echo "请先安装 Python 3: https://www.python.org/downloads/"
    echo "或使用: brew install python3"
    echo ""
    read -p "按回车键关闭..."
    exit 1
fi

echo "[信息] 使用: $($PYTHON --version 2>&1)"
echo ""

if [ ! -f "QiaoDoumayi-local-server.py" ]; then
    echo "[错误] 找不到 QiaoDoumayi-local-server.py"
    echo "当前目录: $(pwd)"
    echo ""
    read -p "按回车键关闭..."
    exit 1
fi

echo "[信息] 正在启动服务，端口 9528..."
echo "[信息] 按 Ctrl+C 可停止服务"
echo ""

$PYTHON QiaoDoumayi-local-server.py -p 9528

if [ $? -ne 0 ]; then
    echo ""
    echo "[错误] 服务启动失败！"
    echo ""
    echo "可能原因："
    echo "  - 端口 9528 已被占用"
    echo "  - 缺少 Python 依赖（如需要可执行: pip3 install Pillow）"
    echo "  - 权限不足"
    echo ""
    read -p "按回车键关闭..."
    exit 1
fi
