@echo off
chcp 65001 >nul
title Environment Test
cls
echo.
echo ========================================
echo   Environment Test
echo ========================================
echo.

echo [1/4] Checking Python...
python --version
if errorlevel 1 (
    echo [FAIL] Python not found!
    goto :error
) else (
    echo [OK] Python is installed
)
echo.

echo [2/4] Checking script file...
if exist "%~dp0QiaoDoumayi-local-server.py" (
    echo [OK] QiaoDoumayi-local-server.py found
) else (
    echo [FAIL] QiaoDoumayi-local-server.py not found!
    goto :error
)
echo.

echo [3/4] Checking port 9528...
netstat -ano | findstr ":9528" >nul
if errorlevel 1 (
    echo [OK] Port 9528 is available
) else (
    echo [WARNING] Port 9528 is already in use
    echo You may need to close other programs using this port
)
echo.

echo [4/4] Testing Python script...
cd /d "%~dp0"
python QiaoDoumayi-local-server.py --help >nul 2>&1
if errorlevel 1 (
    echo [FAIL] Script has errors!
    goto :error
) else (
    echo [OK] Script is ready
)
echo.

echo ========================================
echo   All checks passed!
echo   You can now run: 启动本地接收器.bat
echo ========================================
echo.
pause
exit /b 0

:error
echo.
echo ========================================
echo   Some checks failed!
echo   Please fix the issues above
echo ========================================
echo.
pause
exit /b 1
