@echo off
chcp 65001 >nul
title QiaoDoumayi Local Server
cls
echo.
echo ========================================
echo   QiaoDoumayi Local Server
echo ========================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo Please install Python 3.x from: https://www.python.org/downloads/
    pause
    exit /b 1
)

REM Show Python version
python --version
echo.

REM Check script file
if not exist "%~dp0QiaoDoumayi-local-server.py" (
    echo [ERROR] QiaoDoumayi-local-server.py not found!
    echo Current directory: %~dp0
    pause
    exit /b 1
)

echo [INFO] Starting server on port 9528...
echo [INFO] Press Ctrl+C to stop
echo.

REM Start server
cd /d "%~dp0"
python QiaoDoumayi-local-server.py -p 9528

if errorlevel 1 (
    echo.
    echo [ERROR] Server failed to start!
    echo.
    echo Possible reasons:
    echo   - Port 9528 is already in use
    echo   - Missing Python dependencies
    echo   - Permission denied
    echo.
    pause
    exit /b 1
)

pause
