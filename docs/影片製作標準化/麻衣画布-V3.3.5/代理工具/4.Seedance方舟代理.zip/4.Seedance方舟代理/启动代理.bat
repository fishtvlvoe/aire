@echo off
chcp 65001 >nul
echo.
echo ════════════════════════════════════════════════════════════
echo     Seedance 方舟代理启动器
echo ════════════════════════════════════════════════════════════
echo.

if not exist "node_modules" (
    echo 正在安装依赖...
    call npm install
    if errorlevel 1 (
        echo 依赖安装失败
        pause
        exit /b 1
    )
    echo.
)

echo 正在启动代理...
echo 健康检查: http://127.0.0.1:9530/health
echo.
npm start
pause
