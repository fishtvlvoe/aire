/**
 * Seedance / Seedream（火山方舟）代理
 * 接收前端请求，转发到 ark.cn-beijing.volces.com，解决 CORS。
 * 鉴权：Authorization: Bearer {ARK_API_KEY}（方舟 API Key）
 * 前端 BASE URL 填: http://127.0.0.1:9530
 */

import express from 'express';
import cors from 'cors';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 9530;
const ARK_BASE = 'https://ark.cn-beijing.volces.com/api/v3';

const ARK_API_KEY = process.env.ARK_API_KEY || '';

function getApiKeyFromRequest(req) {
  const auth = req.headers.authorization;
  if (auth && typeof auth === 'string' && auth.startsWith('Bearer ')) {
    const key = auth.slice(7).trim().replace(/\r\n?|\n/g, '');
    if (key) return key;
  }
  if (ARK_API_KEY) return ARK_API_KEY;
  return null;
}

app.use(cors());
app.use(express.json({ limit: '50mb' }));

app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Seedance 方舟代理运行中' });
});

// 转发 /api/v3/* 到火山方舟（视频 + 图片接口均走此处）
app.all('/api/v3/*', async (req, res) => {
  const apiKey = getApiKeyFromRequest(req);
  if (!apiKey) {
    return res.status(400).json({
      code: -1,
      message: '请在画布「模型接口配置」中填写 API KEY，或在代理 .env 中配置 ARK_API_KEY',
    });
  }

  const path = req.path.replace(/^\/api\/v3/, '') || '/';
  const url = `${ARK_BASE}${path}`;
  const method = req.method;
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${apiKey}`,
  };

  try {
    const config = {
      method,
      url,
      headers,
      validateStatus: () => true,
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    };
    if (method !== 'GET' && method !== 'HEAD' && req.body !== undefined) {
      config.data = req.body;
    }
    const response = await axios(config);
    res.status(response.status).set(response.headers).send(response.data);
  } catch (e) {
    console.error('[Proxy Error]', e.message);
    res.status(500).json({ code: -1, message: e.message || '代理请求失败' });
  }
});

app.use((req, res) => {
  res.status(404).json({
    error: '未找到',
    path: req.path,
    message: '方舟代理仅支持 /api/v3/* 路径',
  });
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`方舟代理已启动: http://127.0.0.1:${PORT}，健康检查: /health`);
});
