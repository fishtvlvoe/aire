#!/bin/bash

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║     Seedance / Seedream 方舟代理启动器                       ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# 进入脚本所在目录（双击 .command 时工作目录可能是用户目录）
cd "$(dirname "$0")"

# 检查 Node.js 是否已安装
if ! command -v node &> /dev/null; then
    echo "❌ 错误: 未找到 Node.js"
    echo ""
    echo "请先安装 Node.js: https://nodejs.org/"
    echo ""
    read -p "按回车键关闭..."
    exit 1
fi

echo "✓ Node.js 已找到"
echo ""

# 检查依赖是否已安装
if [ ! -d "node_modules" ]; then
    echo "📦 正在安装依赖..."
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ 依赖安装失败"
        read -p "按回车键关闭..."
        exit 1
    fi
    echo "✓ 依赖安装完成"
    echo ""
fi

# 启动服务器
echo "🚀 正在启动方舟代理..."
echo "   健康检查: http://127.0.0.1:9530/health"
echo ""
npm start

read -p "按回车键关闭..."
